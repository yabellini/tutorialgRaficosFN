# tutorialgRaficosFN
Repositorio del tutorial para generar gráficos en R festejando a Florence Nightingale realizado con learnr
